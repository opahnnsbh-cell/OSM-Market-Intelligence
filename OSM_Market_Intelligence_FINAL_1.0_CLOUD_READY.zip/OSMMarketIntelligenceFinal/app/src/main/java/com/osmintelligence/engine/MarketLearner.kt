package com.osmintelligence.engine

import com.osmintelligence.data.*
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sqrt

/** Transparent local learner. No claim is made about OSM's private algorithm. */
class MarketLearner(private val observations: List<SaleObservation>) {
    data class Fit(val multiplier: Double, val confidence: Double, val samples: Int, val sellRate: Double)

    fun fit(target: PlayerSnapshot, profile: CompetitionProfile): Fit {
        if (observations.isEmpty()) return Fit(1.0, .25, 0, .5)
        val weighted = observations.map { o ->
            val sim = similarity(target, profile, o)
            val ratio = o.askingPrice.toDouble() / o.marketValue.coerceAtLeast(1).toDouble()
            val outcome = if (o.sold) 1.0 else .78
            val time = if (o.sold) 1.0 / (1.0 + .10 * ln(1.0 + o.minutesListed.coerceAtLeast(1))) else .55
            Triple(ratio.coerceIn(.70, 3.0), sim * outcome * time, o.sold)
        }.filter { it.second > .02 }
        if (weighted.isEmpty()) return Fit(1.0, .25, 0, .5)
        val sumW = weighted.sumOf { it.second }
        val m = (weighted.sumOf { it.first * it.second } / sumW).coerceIn(.85, 1.65)
        val nEff = sumW.coerceAtMost(observations.size.toDouble())
        val conf = (.25 + .68 * (1.0 - exp(-nEff / 22.0))).coerceAtMost(.93)
        val sellRate = weighted.count { it.third }.toDouble() / weighted.size
        return Fit(m, conf, weighted.size, sellRate)
    }

    private fun similarity(p: PlayerSnapshot, c: CompetitionProfile, o: SaleObservation): Double {
        var w = 1.0
        if (p.position != PositionGroup.UNKNOWN && o.position != p.position) w *= .72
        p.age?.let { if (o.age != null) w *= exp(-kotlin.math.abs(it-o.age)/9.0) }
        p.primaryRating?.let { if (o.rating != null) w *= exp(-kotlin.math.abs(it-o.rating)/38.0) }
        val valueDistance = kotlin.math.abs(ln((p.marketValue+1.0)/(o.marketValue+1.0)))
        w *= exp(-valueDistance/1.3)
        if (o.seasonPhase != c.seasonPhase) w *= .82
        if (o.timerPhase != c.timerPhase) w *= .90
        if (o.marketActivity != c.marketActivity) w *= .88
        return w
    }
}
