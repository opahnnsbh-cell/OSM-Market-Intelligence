package com.osmintelligence.engine

import com.osmintelligence.data.*
import kotlin.math.exp
import kotlin.math.roundToLong

class SaleEngine {
    fun recommend(player: PlayerSnapshot, profile: CompetitionProfile, observations: List<SaleObservation>, goal: SaleGoal): SaleRecommendation {
        val fit = MarketLearner(observations).fit(player, profile)
        val context = season(profile.seasonPhase)+timer(profile.timerPhase)+activity(profile.marketActivity)+age(player.age)+rating(player.primaryRating)+position(player.position)
        val goalAdj = when(goal) { SaleGoal.SELL_FAST -> -.035; SaleGoal.BALANCED -> 0.0; SaleGoal.MAX_PROFIT -> .035 }
        val learnedBlend = if (fit.samples < 5) 1.0 else fit.multiplier
        val center = (1.0 + context + goalAdj) * learnedBlend
        val q = (1.10*center).coerceIn(1.01, 2.25)
        val b = (1.22*center).coerceAtLeast(q+.03).coerceAtMost(2.45)
        val o = (1.34*center).coerceAtLeast(b+.03).coerceAtMost(2.70)
        val a = (1.49*center).coerceAtLeast(o+.04).coerceAtMost(2.95)
        val confidence = (fit.confidence * .82 + player.sourceConfidence * .18).coerceIn(.20,.95)
        fun band(label:String,m:Double, baseP:Double, mins:Int) = PriceBand(label, roundPrice(player.marketValue*m), (baseP*(.72+.28*fit.sellRate)).coerceIn(.04,.97), mins, confidence)
        val warnings = buildList {
            if (fit.samples < 8) add("الدوري ما زال في مرحلة التعلم؛ سجّل عمليات بيع أكثر لرفع الدقة.")
            if (player.sourceConfidence < .55) add("قراءة الشاشة غير مؤكدة بالكامل؛ راجع القيمة/التقييم قبل اعتماد السعر.")
            if (profile.seasonPhase == SeasonPhase.FINAL) add("نهاية الموسم قد تجعل سلوك المشترين أكثر تقلبًا.")
        }
        return SaleRecommendation(
            quick=band("بيع سريع",q,.82,45), balanced=band("متوازن",b,.66,120), optimal=band("مثالي",o,.50,240), aggressive=band("صعب",a,.30,480),
            modelConfidence=confidence, learnedMultiplier=fit.multiplier, sampleCount=fit.samples, warnings=warnings,
            explanation=listOf("الدوري: ${profile.name}","المرحلة: ${profile.seasonPhase}","العداد: ${profile.timerPhase}","نشاط السوق: ${profile.marketActivity}","الهدف: $goal")
        )
    }
    private fun season(v:SeasonPhase)=when(v){SeasonPhase.OPENING->.055;SeasonPhase.EARLY->.035;SeasonPhase.MID->0.0;SeasonPhase.LATE->-.025;SeasonPhase.FINAL->-.06}
    private fun timer(v:TimerPhase)=when(v){TimerPhase.JUST_RESET->.025;TimerPhase.EARLY->.015;TimerPhase.MID->0.0;TimerPhase.LATE->-.012;TimerPhase.NEAR_RESET->-.025}
    private fun activity(v:MarketActivity)=when(v){MarketActivity.VERY_LOW->-.07;MarketActivity.LOW->-.035;MarketActivity.NORMAL->0.0;MarketActivity.HIGH->.035;MarketActivity.VERY_HIGH->.07}
    private fun age(v:Int?)=when{v==null->0.0;v<=20->.045;v<=23->.025;v<=28->0.0;v<=31->-.025;else->-.05}
    private fun rating(v:Int?)=when{v==null->0.0;v>=115->.045;v>=105->.03;v>=95->.015;v<75->-.015;else->0.0}
    private fun position(v:PositionGroup)=when(v){PositionGroup.ATT->.012;PositionGroup.MID->.006;PositionGroup.DEF->0.0;PositionGroup.GK->-.006;PositionGroup.UNKNOWN->0.0}
    private fun roundPrice(v:Double):Long{ val step=when{v>=100_000_000->500_000L;v>=10_000_000->100_000L;else->50_000L}; return (v/step).roundToLong()*step }
}
