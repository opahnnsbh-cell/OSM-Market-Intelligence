package com.osmintelligence

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.osmintelligence.capture.ScreenCaptureService
import com.osmintelligence.data.*
import com.osmintelligence.engine.SaleEngine
import com.osmintelligence.overlay.OverlayService
import com.osmintelligence.runtime.RuntimeState
import com.osmintelligence.storage.AppRepository
import com.osmintelligence.storage.Preferences
import java.util.UUID

class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{MaterialTheme{OSMApp(this)}}}
}

@Composable private fun OSMApp(a:MainActivity){
    val repo=remember{AppRepository(a)}; val prefs=remember{Preferences(a)}; var tick by remember{mutableIntStateOf(0)}
    val comps=remember(tick){repo.competitions()}; if(prefs.activeCompetitionId==null&&comps.isNotEmpty()) prefs.activeCompetitionId=comps.first().id
    val active=comps.firstOrNull{it.id==prefs.activeCompetitionId}?:comps.firstOrNull(); val player by RuntimeState.player.collectAsState(); val rec by RuntimeState.recommendation.collectAsState(); val running by RuntimeState.captureRunning.collectAsState()
    var tab by remember{mutableIntStateOf(0)}
    val projectionLauncher=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){r->if(r.resultCode==Activity.RESULT_OK&&r.data!=null){
        val i=Intent(a,ScreenCaptureService::class.java).putExtra(ScreenCaptureService.EXTRA_CODE,r.resultCode).putExtra(ScreenCaptureService.EXTRA_DATA,r.data);ContextCompat.startForegroundService(a,i); if(Settings.canDrawOverlays(a)) a.startService(Intent(a,OverlayService::class.java))}}
    val notificationLauncher=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){}
    fun start(){if(Build.VERSION.SDK_INT>=33)notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);if(!Settings.canDrawOverlays(a)){a.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:${a.packageName}")));return}; val m=a.getSystemService(MediaProjectionManager::class.java);projectionLauncher.launch(m.createScreenCaptureIntent())}
    Scaffold(topBar={TopAppBar(title={Text("OSM Market Intelligence")},actions={AssistChip(onClick={},label={Text(if(running)"LIVE" else "OFF")},leadingIcon={Icon(if(running)Icons.Default.Visibility else Icons.Default.VisibilityOff,null)})})},bottomBar={NavigationBar{listOf("الرئيسية" to Icons.Default.Home,"الدوريات" to Icons.Default.Public,"السجل" to Icons.Default.History,"الإعدادات" to Icons.Default.Settings).forEachIndexed{i,x->NavigationBarItem(tab==i,{tab=i},{Icon(x.second,null)},{Text(x.first)})}}}){pad->
        Box(Modifier.padding(pad)){when(tab){0->Dashboard(active,player,rec,running,{if(running)a.startService(Intent(a,ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_STOP))else start()},{g->prefs.saleGoal=g;active?.let{p->player?.let{pl->RuntimeState.recommendation.value=SaleEngine().recommend(pl,p,repo.observations(p.id),g)}}});1->Leagues(comps,prefs,{tick++},repo);2->History(active,repo,{tick++});else->SettingsScreen(prefs)}}}
}

@Composable private fun Dashboard(active:CompetitionProfile?,player:PlayerSnapshot?,rec:SaleRecommendation?,running:Boolean,toggle:()->Unit,goal:(SaleGoal)->Unit){Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
    Text("مركز التحكم",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text(active?.let{"${it.name} • الجولة ${it.currentRound}/${it.totalRounds} • ${it.seasonPhase}"}?:"أضف دوريًا أولًا")
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){SaleGoal.entries.forEach{g->FilterChip(selected=false,onClick={goal(g)},label={Text(when(g){SaleGoal.SELL_FAST->"بيع سريع";SaleGoal.BALANCED->"متوازن";SaleGoal.MAX_PROFIT->"أقصى ربح"})})}}
    Button(toggle,Modifier.fillMaxWidth(),enabled=active!=null){Icon(if(running)Icons.Default.Stop else Icons.Default.PlayArrow,null);Spacer(Modifier.width(8.dp));Text(if(running)"إيقاف القراءة المباشرة" else "تشغيل القراءة فوق OSM")}
    if(player==null) InfoCard("قارئ الشاشة جاهز","افتح لاعبًا داخل OSM بعد تشغيل القراءة؛ سيحاول التطبيق استخراج الاسم والقيمة والعمر والتقييم تلقائيًا.") else {InfoCard(player.name,"قيمة ${money(player.marketValue)} • العمر ${player.age?:"?"} • التقييم ${player.primaryRating?:"?"} • ثقة القراءة ${(player.sourceConfidence*100).toInt()}%")}
    rec?.let{r->Text("توصية البيع",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);listOf(r.quick,r.balanced,r.optimal,r.aggressive).forEach{b->Card(Modifier.fillMaxWidth()){Row(Modifier.padding(14.dp).fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Column{Text(b.label,fontWeight=FontWeight.Bold);Text("احتمال تقريبي ${(b.saleProbability*100).toInt()}%")};Text(money(b.price),style=MaterialTheme.typography.titleLarge)}}};Text("ثقة النموذج ${(r.modelConfidence*100).toInt()}% • ${r.sampleCount} عينة مشابهة");r.warnings.forEach{Text("⚠ $it")}}
}}

@Composable private fun Leagues(comps:List<CompetitionProfile>,prefs:Preferences,refresh:()->Unit,repo:AppRepository){var name by remember{mutableStateOf("")};var round by remember{mutableStateOf("1")};var total by remember{mutableStateOf("38")};var timer by remember{mutableStateOf(TimerPhase.MID)};var activity by remember{mutableStateOf(MarketActivity.NORMAL)};Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("الدوريات والسيرفرات",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);OutlinedTextField(name,{name=it},Modifier.fillMaxWidth(),label={Text("اسم الدوري / البطولة")});Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(round,{round=it.filter(Char::isDigit)},Modifier.weight(1f),label={Text("الجولة")});OutlinedTextField(total,{total=it.filter(Char::isDigit)},Modifier.weight(1f),label={Text("إجمالي")})};EnumDropdown("مرحلة العداد",timer,TimerPhase.entries){timer=it};EnumDropdown("نشاط السوق",activity,MarketActivity.entries){activity=it};Button(onClick={val t=total.toIntOrNull()?.coerceAtLeast(1)?:38;val p=repo.createCompetition(name.ifBlank{"دوري ${comps.size+1}"},t,round.toIntOrNull()?:1,timer,activity);prefs.activeCompetitionId=p.id;name="";refresh()},Modifier.fillMaxWidth()){Text("إضافة وتفعيل الدوري")};comps.forEach{c->Card(onClick={prefs.activeCompetitionId=c.id;refresh()},Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(c.name,fontWeight=FontWeight.Bold);Text("الجولة ${c.currentRound}/${c.totalRounds} • ${c.seasonPhase} • ${c.marketActivity}");if(prefs.activeCompetitionId==c.id)Text("✓ الدوري النشط")}}}}}

@Composable private fun History(active:CompetitionProfile?,repo:AppRepository,refresh:()->Unit){var price by remember{mutableStateOf("")};var value by remember{mutableStateOf("")};var mins by remember{mutableStateOf("120")};var sold by remember{mutableStateOf(true)};val obs=remember(active,refresh){active?.let{repo.observations(it.id)}?:emptyList()};Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("تعليم السوق",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("كل عملية تسجلها تجعل نموذج هذا الدوري أكثر تخصصًا.");if(active==null){Text("فعّل دوريًا أولًا");return@Column};OutlinedTextField(value,{value=it.filter{ch->ch.isDigit()||ch=='.'}},Modifier.fillMaxWidth(),label={Text("قيمة اللاعب بالمليون")});OutlinedTextField(price,{price=it.filter{ch->ch.isDigit()||ch=='.'}},Modifier.fillMaxWidth(),label={Text("سعر العرض بالمليون")});OutlinedTextField(mins,{mins=it.filter(Char::isDigit)},Modifier.fillMaxWidth(),label={Text("مدة العرض بالدقائق")});Row{Switch(sold,{sold=it});Spacer(Modifier.width(8.dp));Text(if(sold)"تم البيع" else "لم يتم البيع")};Button(onClick={val mv=((value.toDoubleOrNull()?:0.0)*1e6).toLong();val ap=((price.toDoubleOrNull()?:0.0)*1e6).toLong();if(mv>0&&ap>0){repo.addObservation(SaleObservation(competitionId=active.id,playerName="manual",age=null,position=PositionGroup.UNKNOWN,rating=null,marketValue=mv,askingPrice=ap,sold=sold,minutesListed=mins.toIntOrNull()?:120,seasonPhase=active.seasonPhase,timerPhase=active.timerPhase,marketActivity=active.marketActivity));value="";price="";refresh()}},Modifier.fillMaxWidth()){Text("تسجيل العينة")};Text("العينات: ${obs.size}",fontWeight=FontWeight.Bold);obs.take(25).forEach{o->Text("${if(o.sold)"✓" else "✕"} ${money(o.marketValue)} → ${money(o.askingPrice)} • ${o.minutesListed} د")}}}

@Composable private fun SettingsScreen(prefs:Preferences){var c by remember{mutableStateOf(prefs.calibration)};Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("المعايرة",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("اضبط موضع شريط السعر كنسبة من عرض/ارتفاع الشاشة إذا لم تتطابق المؤشرات مع جهازك.");CalSlider("بداية الشريط",c.sliderLeft){c=c.copy(sliderLeft=it);prefs.calibration=c};CalSlider("نهاية الشريط",c.sliderRight){c=c.copy(sliderRight=it);prefs.calibration=c};CalSlider("ارتفاع الشريط",c.sliderY){c=c.copy(sliderY=it);prefs.calibration=c};Text("الخصوصية: OCR والتحليل وقاعدة البيانات في هذه النسخة تعمل محليًا على الجهاز؛ لا يوجد رفع تلقائي للصور إلى خادم.")}}

@Composable private fun <T:Enum<T>> EnumDropdown(label:String,value:T,values:List<T>,set:(T)->Unit){var open by remember{mutableStateOf(false)};Box{OutlinedButton({open=true},Modifier.fillMaxWidth()){Text("$label: ${value.name}")};DropdownMenu(open,{open=false}){values.forEach{DropdownMenuItem({Text(it.name)},{set(it);open=false})}}}}
@Composable private fun CalSlider(label:String,v:Float,set:(Float)->Unit){Text("$label ${(v*100).toInt()}%");Slider(v,{set(it)},valueRange=0f..1f)}
@Composable private fun InfoCard(title:String,body:String){Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(title,fontWeight=FontWeight.Bold);Text(body)}}}
private fun money(v:Long)=when{v>=1_000_000_000->"%.2fB".format(v/1e9);v>=1_000_000->"%.1fM".format(v/1e6);v>=1_000->"%.0fK".format(v/1e3);else->v.toString()}
