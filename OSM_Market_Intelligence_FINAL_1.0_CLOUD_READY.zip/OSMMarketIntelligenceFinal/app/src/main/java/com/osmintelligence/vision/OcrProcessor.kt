package com.osmintelligence.vision

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.osmintelligence.data.*

class OcrProcessor {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    data class Token(val text:String,val box:Rect)

    fun process(bitmap: Bitmap, onResult:(PlayerSnapshot?)->Unit, onError:(Throwable)->Unit) {
        recognizer.process(InputImage.fromBitmap(bitmap,0))
            .addOnSuccessListener { onResult(parse(it,bitmap.width,bitmap.height)) }
            .addOnFailureListener(onError)
    }

    internal fun parse(result:Text,w:Int,h:Int):PlayerSnapshot? {
        val t=result.textBlocks.flatMap{it.lines}.flatMap{it.elements}.mapNotNull{e->e.boundingBox?.let{Token(e.text.trim(),it)}}
        if(t.isEmpty()) return null
        val values=t.mapNotNull{ token -> parseMoney(token.text)?.let{token to it} }
        val card=t.filter{it.box.centerX()>w*.64 && it.box.centerY()<h*.82}
        val market=values.filter{it.first.box.centerX()>w*.60}.maxByOrNull{it.second}?.second ?: values.maxByOrNull{it.second}?.second ?: return null
        if(market<100_000) return null
        val name=card.filter{ it.text.length>=3 && it.text.any(Char::isLetter) && it.box.centerY()<h*.30 }
            .maxByOrNull{it.box.width()}?.text?.replace(Regex("\\s+")," ") ?: "Player"
        val nums=card.mapNotNull{it.text.replace(",","").toIntOrNull()?.let{n->it to n}}
        val ratings=nums.filter{it.second in 40..200}.sortedByDescending{it.second}
        val attack=ratings.getOrNull(0)?.second
        val defense=ratings.getOrNull(1)?.second
        val age=nums.filter{it.second in 16..45 && it.first.box.centerY()<h*.36}.minByOrNull{it.first.box.centerY()}?.second
        val pos=when { (attack?:0)-(defense?:0)>25->PositionGroup.ATT; (defense?:0)-(attack?:0)>25->PositionGroup.DEF; else->PositionGroup.UNKNOWN }
        val confidence=listOf(name!="Player",age!=null,attack!=null,market>0).count{it}/4.0
        return PlayerSnapshot(name=name,age=age,position=pos,primaryRating=attack?:defense,attack=attack,defense=defense,marketValue=market,sourceConfidence=confidence)
    }

    private fun parseMoney(raw:String):Long? {
        val s=raw.uppercase().replace(" ","").replace(",","").replace('٫','.').replace('٬',',')
        val m=Regex("([0-9]+(?:\\.[0-9]+)?)([KMB]?)").matchEntire(s)?:return null
        val n=m.groupValues[1].toDoubleOrNull()?:return null
        val mult=when(m.groupValues[2]){"K"->1_000.0;"M"->1_000_000.0;"B"->1_000_000_000.0;else->1.0}
        return (n*mult).toLong()
    }
}
