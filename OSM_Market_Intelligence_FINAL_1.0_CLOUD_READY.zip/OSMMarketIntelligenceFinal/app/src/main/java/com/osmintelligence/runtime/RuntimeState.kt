package com.osmintelligence.runtime

import com.osmintelligence.data.PlayerSnapshot
import com.osmintelligence.data.SaleRecommendation
import kotlinx.coroutines.flow.MutableStateFlow

object RuntimeState {
    val player = MutableStateFlow<PlayerSnapshot?>(null)
    val recommendation = MutableStateFlow<SaleRecommendation?>(null)
    val captureRunning = MutableStateFlow(false)
    val lastError = MutableStateFlow<String?>(null)
}
