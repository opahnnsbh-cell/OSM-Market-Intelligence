package com.osmintelligence.data

enum class SeasonPhase { OPENING, EARLY, MID, LATE, FINAL }
enum class TimerPhase { JUST_RESET, EARLY, MID, LATE, NEAR_RESET }
enum class MarketActivity { VERY_LOW, LOW, NORMAL, HIGH, VERY_HIGH }
enum class PositionGroup { GK, DEF, MID, ATT, UNKNOWN }
enum class SaleGoal { SELL_FAST, BALANCED, MAX_PROFIT }

data class CompetitionProfile(
    val id: String,
    val name: String,
    val totalRounds: Int,
    val currentRound: Int,
    val timerPhase: TimerPhase,
    val marketActivity: MarketActivity,
    val createdAt: Long = System.currentTimeMillis()
) {
    val seasonPhase: SeasonPhase
        get() {
            val p = currentRound.toDouble() / totalRounds.coerceAtLeast(1)
            return when {
                p <= .08 -> SeasonPhase.OPENING
                p <= .25 -> SeasonPhase.EARLY
                p <= .65 -> SeasonPhase.MID
                p <= .88 -> SeasonPhase.LATE
                else -> SeasonPhase.FINAL
            }
        }
}

data class PlayerSnapshot(
    val name: String,
    val age: Int?,
    val position: PositionGroup,
    val primaryRating: Int?,
    val attack: Int? = null,
    val defense: Int? = null,
    val overall: Int? = null,
    val marketValue: Long,
    val matches: Int? = null,
    val goals: Int? = null,
    val assists: Int? = null,
    val formRating: Double? = null,
    val sourceConfidence: Double = .5,
    val capturedAt: Long = System.currentTimeMillis()
)

data class SaleObservation(
    val id: Long = 0,
    val competitionId: String,
    val playerName: String,
    val age: Int?,
    val position: PositionGroup,
    val rating: Int?,
    val marketValue: Long,
    val askingPrice: Long,
    val sold: Boolean,
    val minutesListed: Int,
    val seasonPhase: SeasonPhase,
    val timerPhase: TimerPhase,
    val marketActivity: MarketActivity,
    val timestamp: Long = System.currentTimeMillis()
)

data class PriceBand(
    val label: String,
    val price: Long,
    val saleProbability: Double,
    val estimatedMinutes: Int,
    val confidence: Double
)

data class SaleRecommendation(
    val quick: PriceBand,
    val balanced: PriceBand,
    val optimal: PriceBand,
    val aggressive: PriceBand,
    val modelConfidence: Double,
    val learnedMultiplier: Double,
    val sampleCount: Int,
    val warnings: List<String>,
    val explanation: List<String>
)

data class ScreenCalibration(
    val sliderLeft: Float = .275f,
    val sliderRight: Float = .604f,
    val sliderY: Float = .505f,
    val cardLeft: Float = .68f,
    val cardTop: Float = .07f,
    val cardRight: Float = .93f,
    val cardBottom: Float = .72f
)
