package com.osmintelligence.overlay

import android.app.Service
import android.content.Intent
import android.graphics.*
import android.os.IBinder
import android.view.*
import com.osmintelligence.data.*
import com.osmintelligence.runtime.RuntimeState
import com.osmintelligence.storage.Preferences
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.combine

class OverlayService:Service(){
    private lateinit var wm:WindowManager; private var view:OverlayView?=null; private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main)
    override fun onCreate(){super.onCreate();wm=getSystemService(WINDOW_SERVICE) as WindowManager; val v=OverlayView();view=v
        val p=WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT)
        p.gravity=Gravity.TOP or Gravity.START; wm.addView(v,p)
        scope.launch { combine(RuntimeState.player,RuntimeState.recommendation){a,b->a to b}.collect{v.player=it.first;v.rec=it.second;v.invalidate()} }
    }
    override fun onDestroy(){scope.cancel();view?.let{runCatching{wm.removeView(it)}};super.onDestroy()}; override fun onBind(i:Intent?):IBinder?=null
    inner class OverlayView:View(this){ var player:PlayerSnapshot?=null;var rec:SaleRecommendation?=null
        private val p=Paint(Paint.ANTI_ALIAS_FLAG); private val prefs=Preferences(this@OverlayService)
        override fun onDraw(c:Canvas){super.onDraw(c);val pl=player?:return;val r=rec?:return;val cal=prefs.calibration
            val left=width*cal.sliderLeft;val right=width*cal.sliderRight;val y=height*cal.sliderY
            p.strokeWidth=5f;p.color=Color.argb(190,255,255,255);c.drawLine(left,y,right,y,p)
            val bands=listOf(r.quick,r.balanced,r.optimal,r.aggressive); val min=bands.minOf{it.price}.toFloat();val max=bands.maxOf{it.price}.toFloat().coerceAtLeast(min+1)
            bands.forEachIndexed{i,b->val x=left+(right-left)*(b.price-min)/(max-min);p.color=when(i){0->Color.rgb(40,210,120);1->Color.rgb(255,205,40);2->Color.CYAN;else->Color.rgb(255,90,90)};p.strokeWidth=8f;c.drawLine(x,y-28,x,y+28,p);p.textSize=26f;p.typeface=Typeface.DEFAULT_BOLD;c.drawText(shortMoney(b.price),x-28,y-38,p)}
            val panelLeft=width*.02f; val top=height*.13f;p.color=Color.argb(210,12,26,42);c.drawRoundRect(panelLeft,top,panelLeft+360,top+190,28f,28f,p)
            p.color=Color.WHITE;p.textSize=28f;c.drawText(pl.name.take(22),panelLeft+20,top+40,p);p.textSize=24f;c.drawText("Value ${shortMoney(pl.marketValue)}",panelLeft+20,top+77,p);c.drawText("Optimal ${shortMoney(r.optimal.price)}",panelLeft+20,top+112,p);c.drawText("Confidence ${(r.modelConfidence*100).toInt()}%",panelLeft+20,top+147,p);c.drawText("Samples ${r.sampleCount}",panelLeft+20,top+178,p)
        }
        private fun shortMoney(v:Long)=when{v>=1_000_000_000->"%.1fB".format(v/1e9);v>=1_000_000->"%.1fM".format(v/1e6);v>=1_000->"%.0fK".format(v/1e3);else->v.toString()}
    }
}
