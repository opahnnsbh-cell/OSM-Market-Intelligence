package com.osmintelligence.storage

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.osmintelligence.data.*
import java.util.UUID

class AppRepository(context: Context) : SQLiteOpenHelper(context, "osm_intelligence.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE competitions(id TEXT PRIMARY KEY,name TEXT NOT NULL,totalRounds INTEGER NOT NULL,currentRound INTEGER NOT NULL,timerPhase TEXT NOT NULL,marketActivity TEXT NOT NULL,createdAt INTEGER NOT NULL)""")
        db.execSQL("""CREATE TABLE observations(id INTEGER PRIMARY KEY AUTOINCREMENT,competitionId TEXT NOT NULL,playerName TEXT,age INTEGER,position TEXT,rating INTEGER,marketValue INTEGER NOT NULL,askingPrice INTEGER NOT NULL,sold INTEGER NOT NULL,minutesListed INTEGER NOT NULL,seasonPhase TEXT NOT NULL,timerPhase TEXT NOT NULL,marketActivity TEXT NOT NULL,timestamp INTEGER NOT NULL)""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun saveCompetition(p: CompetitionProfile) {
        writableDatabase.insertWithOnConflict("competitions", null, ContentValues().apply {
            put("id", p.id); put("name", p.name); put("totalRounds", p.totalRounds); put("currentRound", p.currentRound)
            put("timerPhase", p.timerPhase.name); put("marketActivity", p.marketActivity.name); put("createdAt", p.createdAt)
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun createCompetition(name: String, totalRounds: Int, currentRound: Int, timer: TimerPhase, activity: MarketActivity): CompetitionProfile =
        CompetitionProfile(UUID.randomUUID().toString(), name.trim(), totalRounds.coerceAtLeast(1), currentRound.coerceIn(1, totalRounds.coerceAtLeast(1)), timer, activity).also(::saveCompetition)

    fun competitions(): List<CompetitionProfile> = readableDatabase.rawQuery("SELECT * FROM competitions ORDER BY createdAt DESC", null).use { c ->
        buildList {
            while (c.moveToNext()) add(CompetitionProfile(
                id = c.getString(c.getColumnIndexOrThrow("id")), name = c.getString(c.getColumnIndexOrThrow("name")),
                totalRounds = c.getInt(c.getColumnIndexOrThrow("totalRounds")), currentRound = c.getInt(c.getColumnIndexOrThrow("currentRound")),
                timerPhase = TimerPhase.valueOf(c.getString(c.getColumnIndexOrThrow("timerPhase"))),
                marketActivity = MarketActivity.valueOf(c.getString(c.getColumnIndexOrThrow("marketActivity"))),
                createdAt = c.getLong(c.getColumnIndexOrThrow("createdAt"))
            ))
        }
    }

    fun addObservation(o: SaleObservation): Long = writableDatabase.insert("observations", null, ContentValues().apply {
        put("competitionId", o.competitionId); put("playerName", o.playerName); o.age?.let { put("age", it) }
        put("position", o.position.name); o.rating?.let { put("rating", it) }; put("marketValue", o.marketValue)
        put("askingPrice", o.askingPrice); put("sold", if (o.sold) 1 else 0); put("minutesListed", o.minutesListed)
        put("seasonPhase", o.seasonPhase.name); put("timerPhase", o.timerPhase.name); put("marketActivity", o.marketActivity.name); put("timestamp", o.timestamp)
    })

    fun observations(competitionId: String): List<SaleObservation> = readableDatabase.rawQuery(
        "SELECT * FROM observations WHERE competitionId=? ORDER BY timestamp DESC", arrayOf(competitionId)
    ).use { c -> buildList { while (c.moveToNext()) add(SaleObservation(
        id=c.getLong(c.getColumnIndexOrThrow("id")), competitionId=competitionId, playerName=c.getString(c.getColumnIndexOrThrow("playerName")) ?: "",
        age=c.getColumnIndexOrThrow("age").let { if (c.isNull(it)) null else c.getInt(it) }, position=PositionGroup.valueOf(c.getString(c.getColumnIndexOrThrow("position"))),
        rating=c.getColumnIndexOrThrow("rating").let { if(c.isNull(it)) null else c.getInt(it) }, marketValue=c.getLong(c.getColumnIndexOrThrow("marketValue")),
        askingPrice=c.getLong(c.getColumnIndexOrThrow("askingPrice")), sold=c.getInt(c.getColumnIndexOrThrow("sold"))==1,
        minutesListed=c.getInt(c.getColumnIndexOrThrow("minutesListed")), seasonPhase=SeasonPhase.valueOf(c.getString(c.getColumnIndexOrThrow("seasonPhase"))),
        timerPhase=TimerPhase.valueOf(c.getString(c.getColumnIndexOrThrow("timerPhase"))), marketActivity=MarketActivity.valueOf(c.getString(c.getColumnIndexOrThrow("marketActivity"))),
        timestamp=c.getLong(c.getColumnIndexOrThrow("timestamp"))
    )) } }

    fun deleteObservation(id: Long) { writableDatabase.delete("observations", "id=?", arrayOf(id.toString())) }
}

class Preferences(context: Context) {
    private val p = context.getSharedPreferences("osm_settings", Context.MODE_PRIVATE)
    var activeCompetitionId: String?
        get() = p.getString("activeCompetition", null)
        set(v) { p.edit().putString("activeCompetition", v).apply() }
    var saleGoal: SaleGoal
        get() = runCatching { SaleGoal.valueOf(p.getString("saleGoal", SaleGoal.BALANCED.name)!!) }.getOrDefault(SaleGoal.BALANCED)
        set(v) { p.edit().putString("saleGoal", v.name).apply() }
    var calibration: ScreenCalibration
        get() = ScreenCalibration(
            p.getFloat("sl", .275f), p.getFloat("sr", .604f), p.getFloat("sy", .505f),
            p.getFloat("cl", .68f), p.getFloat("ct", .07f), p.getFloat("cr", .93f), p.getFloat("cb", .72f)
        )
        set(v) { p.edit().putFloat("sl",v.sliderLeft).putFloat("sr",v.sliderRight).putFloat("sy",v.sliderY).putFloat("cl",v.cardLeft).putFloat("ct",v.cardTop).putFloat("cr",v.cardRight).putFloat("cb",v.cardBottom).apply() }
}
