package com.osmintelligence.capture

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import androidx.core.app.NotificationCompat
import com.osmintelligence.data.*
import com.osmintelligence.engine.SaleEngine
import com.osmintelligence.runtime.RuntimeState
import com.osmintelligence.storage.AppRepository
import com.osmintelligence.storage.Preferences
import com.osmintelligence.vision.OcrProcessor
import java.util.concurrent.atomic.AtomicBoolean

class ScreenCaptureService:Service(){
    companion object { const val EXTRA_CODE="code"; const val EXTRA_DATA="data"; const val ACTION_STOP="com.osmintelligence.STOP_CAPTURE" }
    private var projection:MediaProjection?=null; private var display:VirtualDisplay?=null; private var reader:ImageReader?=null
    private val busy=AtomicBoolean(false); private var lastFrame=0L; private val ocr=OcrProcessor()
    override fun onCreate(){super.onCreate(); createChannel()}
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{
        if(intent?.action==ACTION_STOP){stopCapture();return START_NOT_STICKY}
        startForeground(11, notification("يحلل شاشة OSM محليًا"))
        val code=intent?.getIntExtra(EXTRA_CODE,Activity.RESULT_CANCELED)?:Activity.RESULT_CANCELED
        val data=if(Build.VERSION.SDK_INT>=33) intent?.getParcelableExtra(EXTRA_DATA,Intent::class.java) else @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_DATA)
        if(code==Activity.RESULT_OK&&data!=null&&projection==null) startProjection(code,data)
        return START_NOT_STICKY
    }
    private fun startProjection(code:Int,data:Intent){
        val mgr=getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection=mgr.getMediaProjection(code,data).also{p->p.registerCallback(object:MediaProjection.Callback(){override fun onStop(){stopCapture()}},Handler(Looper.getMainLooper()))}
        val dm=resources.displayMetrics; val w=dm.widthPixels; val h=dm.heightPixels
        reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2)
        reader!!.setOnImageAvailableListener({ir->
            val now=System.currentTimeMillis(); val img=ir.acquireLatestImage()?:return@setOnImageAvailableListener
            if(now-lastFrame<700||!busy.compareAndSet(false,true)){img.close();return@setOnImageAvailableListener}; lastFrame=now
            try{ val plane=img.planes[0]; val buffer=plane.buffer; val pixelStride=plane.pixelStride; val rowStride=plane.rowStride; val rowPadding=rowStride-pixelStride*w
                val padded=Bitmap.createBitmap(w+rowPadding/pixelStride,h,Bitmap.Config.ARGB_8888); padded.copyPixelsFromBuffer(buffer)
                val bmp=Bitmap.createBitmap(padded,0,0,w,h); padded.recycle()
                ocr.process(bmp,{player->bmp.recycle(); if(player!=null) onPlayer(player); busy.set(false)},{e->bmp.recycle();RuntimeState.lastError.value=e.message;busy.set(false)})
            }catch(e:Throwable){RuntimeState.lastError.value=e.message;busy.set(false)}finally{img.close()}
        },Handler(Looper.getMainLooper()))
        display=projection!!.createVirtualDisplay("OSMIntel",w,h,dm.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader!!.surface,null,null)
        RuntimeState.captureRunning.value=true
    }
    private fun onPlayer(player:PlayerSnapshot){
        RuntimeState.player.value=player
        val repo=AppRepository(this); val prefs=Preferences(this); val comps=repo.competitions(); val active=comps.firstOrNull{it.id==prefs.activeCompetitionId}?:comps.firstOrNull()
        if(active!=null) RuntimeState.recommendation.value=SaleEngine().recommend(player,active,repo.observations(active.id),prefs.saleGoal)
    }
    private fun stopCapture(){RuntimeState.captureRunning.value=false;display?.release();display=null;reader?.close();reader=null;projection?.stop();projection=null;stopForeground(STOP_FOREGROUND_REMOVE);stopSelf()}
    override fun onDestroy(){display?.release();reader?.close();projection=null;RuntimeState.captureRunning.value=false;super.onDestroy()}
    override fun onBind(intent:Intent?)=null
    private fun createChannel(){if(Build.VERSION.SDK_INT>=26)(getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel("capture","OSM screen analysis",NotificationManager.IMPORTANCE_LOW))}
    private fun notification(text:String)=NotificationCompat.Builder(this,"capture").setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("OSM Market Intelligence").setContentText(text).setOngoing(true).build()
}
