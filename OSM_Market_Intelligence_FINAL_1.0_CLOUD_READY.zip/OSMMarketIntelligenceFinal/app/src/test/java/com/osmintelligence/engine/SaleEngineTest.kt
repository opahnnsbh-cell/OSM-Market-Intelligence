package com.osmintelligence.engine
import com.osmintelligence.data.*
import org.junit.Assert.*
import org.junit.Test
class SaleEngineTest {
 @Test fun bandsIncrease(){val p=PlayerSnapshot("X",20,PositionGroup.ATT,110,marketValue=50_000_000,sourceConfidence=1.0);val c=CompetitionProfile("1","L",38,3,TimerPhase.MID,MarketActivity.NORMAL);val r=SaleEngine().recommend(p,c,emptyList(),SaleGoal.BALANCED);assertTrue(r.quick.price<r.balanced.price&&r.balanced.price<r.optimal.price&&r.optimal.price<r.aggressive.price)}
 @Test fun observationsRaiseConfidence(){val p=PlayerSnapshot("X",22,PositionGroup.MID,100,marketValue=20_000_000,sourceConfidence=1.0);val c=CompetitionProfile("1","L",38,10,TimerPhase.MID,MarketActivity.NORMAL);val obs=(1..40).map{SaleObservation(competitionId="1",playerName="x",age=22,position=PositionGroup.MID,rating=100,marketValue=20_000_000,askingPrice=26_000_000,sold=true,minutesListed=120,seasonPhase=c.seasonPhase,timerPhase=c.timerPhase,marketActivity=c.marketActivity)};val a=SaleEngine().recommend(p,c,emptyList(),SaleGoal.BALANCED);val b=SaleEngine().recommend(p,c,obs,SaleGoal.BALANCED);assertTrue(b.modelConfidence>a.modelConfidence)}
}
