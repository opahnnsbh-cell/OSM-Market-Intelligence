# OSM Market Intelligence 1.0

Android assistant for analysing OSM player screens and learning a league-specific transfer-market model from the user's own sale observations.

## Production feature set in this source tree
- Multiple independent league/server profiles.
- Season phase, timer phase, market activity and user sale goal as pricing context.
- Local SQLite history of sold/unsold listings.
- Similarity-weighted adaptive market learner per competition.
- Four sale bands: quick, balanced, optimal and aggressive, with estimated probability/confidence.
- Android MediaProjection capture service with Android 14+ foreground-service declarations.
- On-device ML Kit OCR pipeline; no screenshot upload is implemented.
- Full-screen transparent overlay with price markers, player card and confidence/sample count.
- Screen calibration controls for slider alignment across phone aspect ratios.
- Runtime confidence/warning system for weak OCR and low-data leagues.
- Unit tests for monotonic price bands and learning confidence.

## Important accuracy note
This app does not claim access to OSM's private transfer algorithm. Its estimates are a transparent local model that adapts to the sales you record for each competition. Until enough observations exist, recommendations are deliberately labelled low-confidence.

## Build
Open the root folder in a current Android Studio installation with Android SDK 35 installed and build the `app` module. The project targets Android 15 / API 35 and supports Android 9+ (API 28+).

## First run
1. Add a competition and make it active.
2. Grant "display over other apps" when requested.
3. Start live reading and approve Android's screen-capture consent dialog.
4. Open an OSM player page. The app analyses frames locally and updates the overlay.
5. Use History to record real sale outcomes; this increases league-specific confidence.
6. If marker alignment is off, use Settings > Calibration.

## Known platform limitation
Android requires explicit user consent for every MediaProjection session on modern Android. The app cannot legally or technically bypass that system dialog.
