# Cloud APK build

This repository includes `.github/workflows/build-apk.yml`.
The workflow installs JDK 17, Android SDK 35, Gradle 8.9, runs unit tests, builds an installable debug APK, verifies the APK path, and uploads it as a GitHub Actions artifact named `OSM-Market-Intelligence-APK`.
